#include <Romi32U4.h>
#include <Arduino.h>

class Rangefinder{

    public:
    void setup();
    void loop();
    float getDistanceCM();


    private:
    float distance;

};

